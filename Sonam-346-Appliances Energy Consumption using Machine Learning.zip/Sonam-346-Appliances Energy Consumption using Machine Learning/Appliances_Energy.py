import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings
from scipy.stats.mstats import winsorize
from scipy.stats import boxcox
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import  StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import mean_squared_error,r2_score
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.neighbors import KNeighborsRegressor
from xgboost import XGBRegressor
import streamlit as st

@st.cache_data   # decorator to load data faster for every time
def load_data():
    df = pd.read_csv("energydata_complete.csv")
    X = df.drop(["Appliances", "date"], axis=1)
    y = df["Appliances"]
    return X, y

@st.cache_resource
def train_models():
    X, y = load_data()
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)
  #model training
    models = {
        "Linear Regression": LinearRegression(),
        "KNN": KNeighborsRegressor(n_neighbors=5),
        "XGBoost": XGBRegressor(n_estimators=100, max_depth=4),
        "Random Forest": RandomForestRegressor(n_estimators=100),
        "Decision Tree": DecisionTreeRegressor()
       }
  #saving the train data on different models
    for i in models:
        models[i].fit(X_train, y_train)

    return models, scaler, X.columns.tolist()
  #models=diff trained models, scaler is used to scale the incoming data, X.col list gives all feature names

  # Load and train
models, scaler, feature_names = train_models()

# Streamlit User interface locally
st.title(":green[Appliance Energy Consumption Predictor]")
st.write("Predict :red[Energy consumed by appliances] using Regressor models")

# Select model
model_choice = st.selectbox("[Select model]", list(models.keys()))

#Entering feature values
st.subheader("Enter Feature Values")
input_data = [] #creating empty list to store user input numerical values of features
cols = st.columns(3)    #organizing features in 3 columns keenly

for idx, feature in enumerate(feature_names):
    with cols[idx % 3]:
        val = st.number_input(f"{feature}", value=0.0, format="%.4f")
        input_data.append(val)

# Predict
if st.button("Predict"):
    X_input = np.array(input_data).reshape(1, -1) #converting i/p features into array n scaling for prediction
    X_scaled = scaler.transform(X_input)
    prediction = models[model_choice].predict(X_scaled)[0]
    st.success(f"Predicted Appliance Energy Consumption: {prediction:.2f} Wh")

# Query point example
if st.button("Use Sample Query Point"):
    query_point = [19.89, 47.596667, 5.33, 7.0, 1, 0, 0, 0, 0, 0,
                   0, 0, 0, 0, 0, 45.0, 33.3, 0.0, 0.0, 0.0,
                   0.0, 0.0, 0.0,10.0,0.0, 0.0, 0.0, 0.003333]
    X_input = np.array(query_point).reshape(1, -1)
    X_scaled = scaler.transform(X_input)
    prediction = models[model_choice].predict(X_scaled)[0]
    st.info("Using sample query point.")
    st.success(f"Predicted Appliance Energy Consumption: {prediction:.2f} Wh")